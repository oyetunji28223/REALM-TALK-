#!/bin/bash

echo 'Deploying REALM-TALK∞ system...'