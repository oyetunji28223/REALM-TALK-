# Ipfs File Share Module

This is part of REALM-TALK∞.